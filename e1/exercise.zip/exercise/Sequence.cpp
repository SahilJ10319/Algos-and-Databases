#include "Sequence.h"

Sequence::Sequence()
{
}

Sequence::~Sequence()
{
}

void Sequence::insert(double n)
{   
}

void Sequence::clear()
{
}

int Sequence::size() const
{
    return 0;
}

double Sequence::stdDeviation() const
{
    return 0;
}

